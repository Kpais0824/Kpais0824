package com.github.dhl.sample

import androidx.lifecycle.ViewModel

class SampleViewModel : ViewModel() {

}
