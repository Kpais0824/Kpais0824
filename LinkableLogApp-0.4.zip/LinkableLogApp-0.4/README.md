# LinkableLogApp
The power of android logcat, now developer can jump right to the log printed from.
